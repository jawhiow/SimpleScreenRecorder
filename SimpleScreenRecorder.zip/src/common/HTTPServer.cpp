/*
Copyright (c) 2012-2020 Maarten Baert <maarten-baert@hotmail.com>

This file is part of SimpleScreenRecorder.

SimpleScreenRecorder is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

SimpleScreenRecorder is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with SimpleScreenRecorder.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "HTTPServer.h"
#include "Logger.h"
#include "PageRecord.h"

HTTPServer::HTTPServer(PageRecord* page_record) {
    m_server = new QTcpServer(this);
    m_page_record = page_record;
    
    connect(m_server, SIGNAL(newConnection()), this, SLOT(OnNewConnection()));
}

HTTPServer::~HTTPServer() {
    Stop();
    delete m_server;
}

bool HTTPServer::Start(int port) {
    if (!m_server->listen(QHostAddress::Any, port)) {
        Logger::LogError("[HTTPServer::Start] " + Logger::tr("Error: Could not start HTTP server on port %1!").arg(port));
        return false;
    }
    
    Logger::LogInfo("[HTTPServer::Start] " + Logger::tr("HTTP server listening on port %1.").arg(port));
    return true;
}

void HTTPServer::Stop() {
    if (m_server->isListening()) {
        m_server->close();
        Logger::LogInfo("[HTTPServer::Stop] " + Logger::tr("HTTP server stopped."));
    }
}

QJsonObject HTTPServer::CreateSuccessResponse(const QJsonObject& data) {
    QJsonObject response;
    response["success"] = true;
    response["data"] = data;
    return response;
}

QJsonObject HTTPServer::CreateErrorResponse(const QString& message) {
    QJsonObject response;
    response["success"] = false;
    response["error"] = message;
    return response;
}

void HTTPServer::OnNewConnection() {
    QTcpSocket* socket = m_server->nextPendingConnection();
    connect(socket, SIGNAL(readyRead()), this, SLOT(OnReadyRead()));
    connect(socket, SIGNAL(disconnected()), this, SLOT(OnDisconnected()));
    m_request_buffers[socket] = QByteArray();
}

void HTTPServer::OnReadyRead() {
    QTcpSocket* socket = qobject_cast<QTcpSocket*>(sender());
    if (!socket)
        return;
    
    QByteArray& buffer = m_request_buffers[socket];
    buffer.append(socket->readAll());
    
    // Check if we have a complete HTTP request
    if (buffer.contains("\r\n\r\n")) {
        HandleRequest(socket, buffer);
        buffer.clear();
    }
}

void HTTPServer::OnDisconnected() {
    QTcpSocket* socket = qobject_cast<QTcpSocket*>(sender());
    if (!socket)
        return;
    
    m_request_buffers.remove(socket);
    socket->deleteLater();
}

void HTTPServer::HandleRequest(QTcpSocket* socket, const QByteArray& request) {
    QStringList lines = QString(request).split("\r\n");
    if (lines.isEmpty()) {
        SendResponse(socket, 400, "text/plain", "Bad Request");
        return;
    }
    
    QStringList requestLine = lines[0].split(" ");
    if (requestLine.size() < 3) {
        SendResponse(socket, 400, "text/plain", "Bad Request");
        return;
    }
    
    QString method = requestLine[0];
    QString path = requestLine[1];
    
    // Parse headers
    QMap<QString, QString> headers;
    for (int i = 1; i < lines.size(); ++i) {
        if (lines[i].isEmpty())
            break;
        
        int colonPos = lines[i].indexOf(':');
        if (colonPos > 0) {
            QString key = lines[i].left(colonPos).trimmed().toLower();
            QString value = lines[i].mid(colonPos + 1).trimmed();
            headers[key] = value;
        }
    }
    
    // Find the body
    QByteArray body;
    int headerEnd = request.indexOf("\r\n\r\n");
    if (headerEnd >= 0 && headerEnd + 4 < request.size()) {
        body = request.mid(headerEnd + 4);
    }
    
    // Handle API requests
    if (path.startsWith("/api/")) {
        QString apiPath = path.mid(5);
        QJsonObject jsonRequest;
        
        if (!body.isEmpty()) {
            QJsonDocument doc = QJsonDocument::fromJson(body);
            if (!doc.isNull() && doc.isObject()) {
                jsonRequest = doc.object();
            }
        }
        
        HandleAPI(socket, apiPath, jsonRequest);
        return;
    }
    
    // Default response for other paths
    QByteArray content = "SimpleScreenRecorder API Server";
    SendResponse(socket, 200, "text/plain", content);
}

void HTTPServer::HandleAPI(QTcpSocket* socket, const QString& path, const QJsonObject& json) {
    QJsonObject response;
    
    if (path == "status") {
        response = HandleAPIStatus();
    } else if (path == "record/start") {
        response = HandleAPIStartRecording();
    } else if (path == "record/pause") {
        response = HandleAPIPauseRecording();
    } else if (path == "record/cancel") {
        response = HandleAPICancelRecording();
    } else if (path == "record/save") {
        response = HandleAPISaveRecording();
    } else {
        response = CreateErrorResponse("Unknown API endpoint");
    }
    
    SendJsonResponse(socket, 200, response);
}

void HTTPServer::SendResponse(QTcpSocket* socket, int status, const QByteArray& content_type, const QByteArray& content) {
    QByteArray response;
    
    // Status line
    QString statusText;
    switch (status) {
        case 200: statusText = "OK"; break;
        case 400: statusText = "Bad Request"; break;
        case 404: statusText = "Not Found"; break;
        case 500: statusText = "Internal Server Error"; break;
        default: statusText = "Unknown";
    }
    
    response.append(QString("HTTP/1.1 %1 %2\r\n").arg(status).arg(statusText).toUtf8());
    
    // Headers
    response.append(QString("Content-Type: %1\r\n").arg(QString(content_type)).toUtf8());
    response.append(QString("Content-Length: %1\r\n").arg(content.size()).toUtf8());
    response.append("Connection: close\r\n");
    response.append("Access-Control-Allow-Origin: *\r\n");
    
    // Empty line + body
    response.append("\r\n");
    response.append(content);
    
    socket->write(response);
    socket->flush();
    socket->close();
}

void HTTPServer::SendJsonResponse(QTcpSocket* socket, int status, const QJsonObject& json) {
    QJsonDocument doc(json);
    QByteArray content = doc.toJson();
    SendResponse(socket, status, "application/json", content);
}

QJsonObject HTTPServer::HandleAPIStatus() {
    QJsonObject data;
    
    // Get information about the current state
    if (m_page_record) {
        // Convert information from PageRecord to JSON format
        // These values will need to be exposed from PageRecord to be accessible here
        data["is_recording"] = m_page_record->IsRecording();
        data["is_paused"] = m_page_record->IsPaused();
        data["file_name"] = m_page_record->GetCurrentFileName();
        data["file_size"] = QString::number(m_page_record->GetCurrentFileSize());
        data["total_time"] = m_page_record->GetTotalTime();
    }
    
    return CreateSuccessResponse(data);
}

QJsonObject HTTPServer::HandleAPIStartRecording() {
    if (!m_page_record)
        return CreateErrorResponse("No access to recording page");
    
    // If paused, unpause, else start recording
    if (m_page_record->IsPaused()) {
        m_page_record->OnRecordStartPause();
        return CreateSuccessResponse({{"action", "resumed"}});
    } else if (!m_page_record->IsRecording()) {
        m_page_record->OnRecordStart();
        return CreateSuccessResponse({{"action", "started"}});
    } else {
        return CreateErrorResponse("Already recording");
    }
}

QJsonObject HTTPServer::HandleAPIPauseRecording() {
    if (!m_page_record)
        return CreateErrorResponse("No access to recording page");
    
    // Can only pause if currently recording and not already paused
    if (m_page_record->IsRecording() && !m_page_record->IsPaused()) {
        m_page_record->OnRecordPause();
        return CreateSuccessResponse();
    } else {
        return CreateErrorResponse("Not recording or already paused");
    }
}

QJsonObject HTTPServer::HandleAPICancelRecording() {
    if (!m_page_record)
        return CreateErrorResponse("No access to recording page");
    
    // Can only cancel if currently recording or paused
    if (m_page_record->IsRecording()) {
        m_page_record->OnRecordCancel(false); // false = no confirmation dialog
        return CreateSuccessResponse();
    } else {
        return CreateErrorResponse("Not recording");
    }
}

QJsonObject HTTPServer::HandleAPISaveRecording() {
    if (!m_page_record)
        return CreateErrorResponse("No access to recording page");
    
    // Can only save if currently recording or paused
    if (m_page_record->IsRecording()) {
        m_page_record->OnRecordSave(false); // false = no confirmation dialog
        return CreateSuccessResponse();
    } else {
        return CreateErrorResponse("Not recording");
    }
} 